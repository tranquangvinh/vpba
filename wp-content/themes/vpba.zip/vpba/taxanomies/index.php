<?php 
include_once(__DIR__ . '/story.php');
<div class="container">
	<div class="row breadscumb-row">
		<div class="col-md-2 col-sm-3 no-wrap">
			<div class="title-home">
				<a href="<?php echo get_home_url(); ?>">
					<?php echo $args['title']; ?>
				</a>

			</div>
		</div>
		<div class="col-md-6 col-sm-6 no-wrap">
	        <?php do_action('marquee_header') ?>
		</div>
		<!-- get current time -->
		<div class="col-md-4 col-sm-3 text-right" id="current-time"></div>
	</div>
</div>
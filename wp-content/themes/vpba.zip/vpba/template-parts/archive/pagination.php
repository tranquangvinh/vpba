 <div class="pagination-category">
	<?php do_action('pagination'); ?>
</div>
<div class="sidebar">
	<div class="title-header d-flex align-items-end">
	    <a class="main mr-auto" href="">
	    	<span>Hình ảnh hoạt động</span>
	    </a>
	    <div class="clearfix"></div>
	</div>
	<?php do_action('sliders'); ?>

    <div class="title-header d-flex align-items-end mt-4">
        <a class="main mr-auto" href="">
            <span>Video</span>
        </a>
        <div class="clearfix"></div>
    </div>
    <?php do_action('videos'); ?>

    <div class="title-header d-flex align-items-end mt-4">
        <a class="main mr-auto" href="">
            <span>Quảng cáo</span>
        </a>
        <div class="clearfix"></div>
    </div>
    <?php do_action('advertisements'); ?>

    <div class="title-header custom d-flex align-items-end mt-4">
        <a class="main mr-auto" href="">
            <span>Liên kết website</span>
        </a>
        <div class="clearfix"></div>
    </div>
    <?php do_action('link_website'); ?>

    <div class="title-header d-flex align-items-end mt-4">
        <a class="main mr-auto" href="">
            <span>Thông tin tỷ giá</span>
        </a>
        <div class="clearfix"></div>
    </div>
    <?php do_action('exchange_rate_info'); ?>
</div>

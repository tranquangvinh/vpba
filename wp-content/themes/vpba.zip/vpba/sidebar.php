<div class="sidebar">
    <?php do_action('sliders'); ?>
    <?php do_action('posts_random'); ?>
</div>

<?php 
include_once(__DIR__ . '/render/pagination.php');

function action_pagination(){
    render_pagination();
}